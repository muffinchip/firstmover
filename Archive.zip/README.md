# FirstMover — Analytics Update

Adds:
- Narrative analytics per platform (users then vs now, milestone fact)
- Cumulative users chart with dashed vertical "you joined" line
- Gmail scope UX (re-consent & hints)
- Render-friendly deploy config

**Note:** Numbers in `data/adoption_curves.json` are illustrative seeds. Replace with your preferred sources for accuracy.
